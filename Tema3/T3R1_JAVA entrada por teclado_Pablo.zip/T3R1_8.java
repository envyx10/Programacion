import java.util.Scanner;

public class T3R1_8 {
    
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        
        int horas;
        int salario;

        System.out.println("Horas trabajas durante la semana: ");

        horas = entrada.nextInt();
        salario = horas * 12;

        System.out.println("Su salario es de: " + salario + " euros ");
        









    }





}
