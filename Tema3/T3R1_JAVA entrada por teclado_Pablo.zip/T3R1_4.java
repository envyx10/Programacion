import java.util.Scanner;

public class T3R1_4 {
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);

        double num1;
        double num2;

        System.out.println("Inserte el valor de x: ");

        num1 = entrada.nextDouble();     

        System.out.println("Inserte el valor de y: ");
  
        num2 = entrada.nextDouble();

        System.out.println("El resultado de su suma es: " + (num1+num2) );
        System.out.println("El resultado de su resta es: " + (num1-num2) );
        System.out.println("El resultado de su multiplicacion es: " + (num1*num2) );
        System.out.printf("El resultado de su division es: %.10f" , (num1/num2) );
        

        
      





        


       
        













    }
}
