
// 7 Igual que el programa anterior, pero esta vez la pirámide estará hueca

public class T1R1_7 {
    public static void main(String[] args){
        System.out.println("\033[31m     * ");
        System.out.println("    * * ");
        System.out.println("   *   * ");
        System.out.println("  *     * ");
        System.out.println(" ********* \033[0m");
        

    }
    

}
