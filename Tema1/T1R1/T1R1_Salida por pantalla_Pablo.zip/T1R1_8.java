
// 8 Igual que los anteriores pero al reves

public class T1R1_8 {
    public static void main(String[] args){
        System.out.println("\033[31m ********* ");
        System.out.println("  *     *");
        System.out.println("   *   * ");
        System.out.println("    * * ");
        System.out.println("     * \033[0m");
        

    }


}
