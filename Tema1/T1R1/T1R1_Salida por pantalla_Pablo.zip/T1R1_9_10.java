public class T1R1_9_10 {
    
    public static void main(String[] args){

        System.out.println("\033[34m     * ");
        System.out.println("    *** ");
        System.out.println("   ***** ");
        System.out.println("  ******* ");
        System.out.println(" ********* ");    
        System.out.println("    ***     ");  
        System.out.println("    ***     ");
        System.out.println("    ***      ");   

    }




}
