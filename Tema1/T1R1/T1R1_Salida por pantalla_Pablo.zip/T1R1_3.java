
// 3 Escribe un programa que muestre por pantalla 10 palabras en inglés

public class T1R1_3{
    public static void main(String[] args){
        
        System.out.printf("%2$-20s %s\n","computer","ordenador");
        System.out.printf("%2$-20s %s\n","student","estudiante");
        System.out.printf("%2$-20s %s\n","cat","gato");
        System.out.printf("%2$-20s %s\n","dog","perro");
        System.out.printf("%2$-20s %s\n","machine","máquina");
        System.out.printf("%2$-20s %s\n","penguin","pinguino");
        System.out.printf("%2$-20s %s\n","light","luz");
        System.out.printf("%2$-20s %s\n","green","verde");
        System.out.printf("%2$-20s %s\n","book","libro");
        System.out.printf("%2$-20s %s\n","ocean","oceano");


    }


    
}
