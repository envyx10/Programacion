
// 4 Escribe un programa que muestre tu horario de clase.
// 5 Modifica el programa añadiendo colores.


public class T1R1_4_5 {
    public static void main(String[] args){

        System.out.printf(
            "\n%-35s %-35s %-35s %-35s %-35s\n","Lunes","Martes","Miercoles","Jueves","Viernes");
        System.out.printf(
            "\033[30m%-35s %-35s %-35s %-35s %-35s\n","programacion","programacion","Sistemas informaticos","Base de datos","Sistemas informaticos");
        System.out.printf(
            "\033[31m%-35s %-35s %-35s %-35s %-35s\n","programacion","programacion","Sistemas informaticos","Base de datos","Sistemas informaticos");
        System.out.printf(
            "\033[32m%-35s %-35s %-35s %-35s %-35s\n","Lenguaje de marcas","Lenguajede marcas","Sistemas informaticos","Entornos","Sistemas informaticos\n");
        System.out.printf(
            "\033[33m%-35s %-35s %-35s %-35s %-35s\n","viena time","viena time","viena time","viena time","viena time\n");
        System.out.printf(
            "\033[34m%-35s %-35s %-35s %-35s %-35s\n","Lenguaje de marcas","Lenguaje de marcas","Programacion","Entornos","Fol");
        System.out.printf(
            "\033[35m%-35s %-35s %-35s %-35s %-35s\n","Base de datos","base de datos","Programacion","Programacion","Fol");
        System.out.printf(
            "\033[36m%-35s %-35s %-35s %-35s %-35s\n","Base de datos","base de datos","Entornos","Programacion","Fol\n");

        }
    
    
    
    
    
    }





