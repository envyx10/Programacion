
// 6 Escribe un programa que pinte por pantalla una pirámide rellena a base de asteriscos.
public class T1R1_6 {
    public static void main(String[] args){
        System.out.println("\033[31m     * ");
        System.out.println("    *** ");
        System.out.println("   ***** ");
        System.out.println("  ******* ");
        System.out.println(" ********* \033[0m");
        

    }

}
