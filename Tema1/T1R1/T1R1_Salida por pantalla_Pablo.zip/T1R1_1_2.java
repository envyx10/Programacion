    
    // 1 Escribe un programa en JAVA que muestre tu nombre por pantalla.
    // 2 Modifica el programa para que además se muestre tu dirección, número y teléfono.
    public class T1R1_1_2 {
        public static void main(String[] args){
            System.out.println("\n\033[35m\033[1m\033[3mMi nombre es: ");
            System.out.println("\t\"Pablo\"\n") ;  
            System.out.println("Mi direccion: ");
            System.out.println("\t\"Calle José Sanchez Rando\"\n"); 
            System.out.println("Mi telefono: ");
            System.out.println("\t\"698 424 956\"\n");    
            System.out.print("\u2623  \u2623  \u2623");


        }
        
    }
              