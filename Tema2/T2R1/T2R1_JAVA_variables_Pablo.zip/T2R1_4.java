public class T2R1_4 {
    
    public static void main(String[] args) {
        

        double euros = 10.00;
        double pesetas = 166.3860;
        double conversion;

        conversion = (euros * pesetas);

        System.out.println(euros + " euros son " + conversion + " pesetas ");





    


        
    }



}
