public class T2R1_5 {


    public static void main(String[] args) {

        double pesetas = 10000;
        double conversion;

        conversion = (pesetas / 166.3860);

        System.out.println( pesetas + " pesetas son " + conversion + " euros");
         


    }
        

     











}
