public class T2R1_6 {

    public static void main(String[] args) {
        
        double base = 22.75;
        double iva = 4.78;
        double resultado = (base * 1.21);

        System.out.println("Base imponible \t" + base);
        System.out.println("IVA \t\t" + iva);
        System.out.println("--------------------");
        System.out.printf("total         %.5f" , resultado );
 








    }




    
}
