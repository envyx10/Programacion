public class T2R1_2 {
    
    public static void main(String[] args) { 
        
        String nombre = "pablo Diaz";
        System.out.println("Su nombre es: " + nombre);


    }





    
}
