public class T2R1_1 {

    public static void main(String[] args){
        
        int x = 144;
        int y = 999;
        double division = (double) x /(double) y;
    
        System.out.printf(" El valor de x es = %d\n" , x);
        System.out.printf(" El valor de y es = %d\n" , y);
        System.out.printf(" El valor de y es = %d\n" , x+y);
        System.out.printf(" El valor de y es = %d\n" , x-y);
        System.out.printf(" El valor de y es = %f\n" , division);
        System.out.printf(" El valor de y es = %d\n" , x * y);
            
        
    }
        

}
