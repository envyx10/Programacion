

public class T2R1_3 {


    public static void main(String[] args) {
        
        String nombre = "Pablo";
        String direccion = "Calle Jose Sanchez Rando 2";
        String telefono = "698 424 956";
        
        System.out.println("Su nombre es: " + nombre + "\nUsted vive en: "  + direccion + "\nSu telefono de contacto es el siguiente: " + telefono);




    }



    
}
