public class T2R1_8 {

    public static void main(String[] args) {
        
        char num1 = 'S';
        char num2 = 'A';
        char num3 = 'L';
        char num4  = 'U';
        char num5 = 'D';
        String texto = " " + num1 + num2 + num3 + num4 + num5 ;
        
        System.out.println(texto);



    }


    
    
}
