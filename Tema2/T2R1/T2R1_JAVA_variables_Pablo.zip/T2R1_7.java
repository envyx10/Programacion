public class T2R1_7 {
    

    public static void main(String[] args) {
        

        char primeraletra = 'a';
        char ultimaletra = 'z';
        String abc = "abecedario" ;

        System.out.println( primeraletra + "\t"+ ultimaletra + "\t" + abc );





    }



} 
